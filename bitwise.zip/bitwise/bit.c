#include <stdio.h>
void display(unsigned char n2);
int main()
{
    int pos1;
    int pos2;
    unsigned char n1  = 255;
    unsigned char n2 = 0;
    printf("Enter start pos\n");
    scanf("%d", &pos1);
    printf("End limit\n");
    scanf("%d", &pos2);
    for(int i = pos1; pos2!= 0; i++, pos2--) {
        n2 = (n1 & (1 << i)) ^ n2;
    }
    printf("%d\n", n2);
    display(n2);
}
void display(unsigned char n2)
{
    for(int i = 7; i >= 0; i--) {
        if(n2&(1<<i)){
            printf("1");
        } else {
            printf("0");
        }        
    }
}
