#include<stdio.h>
void display(unsigned char num);
void reverse(unsigned char num);
int main()
{
	unsigned char num;
	printf("Enter a num\n");
	scanf("%hhd", &num);
//	display(num);
	reverse(num);
}
void reverse(unsigned char num)
{
	int i = 0;
	int j = 7;
	unsigned char temp = 0;
	while(i != 8) {
		temp =  ( (num & 1) << 7 );
		num = num >> 1;
		num = num | temp;
		i++;
	}
	//i++;
	printf("\n%d\n", num);
	display(num);
}
void display(unsigned char num)
{
	for(int i = 0; i < 8; i++) {
		if(num & 128) {
			printf("1");
		} else {
			printf("0");
		}
		num = num << 1;
	}
}
