#include<stdio.h>
void display(unsigned char num);
int palin(unsigned char num);
int main()
{
	unsigned char num;
	printf("Enter number\n");
	scanf("%hhd", &num);
	display(num);
	if(palin(num)) {
		printf("\npalindrome\n");
	} else {
		printf("\nNot palindrome\n");
	}
}
int palin(unsigned char num)
{
	int i = 0;
	int flag1;
	int flag2;
	while(i != 8) {
		flag1 = ((128 >> i) & num);
		flag2 = ((1 << i) & num);
		if (flag1 && flag2) {
			i++;
			continue;
		} else if(flag1 == flag2) {
			i++;
			continue;	//return 0;
			//printf("Not palindrom\n");
		} else {
			return 0;
	
		}
	}
	return 1;
}
void display(unsigned char num)
{
	int i;
	for(int i = 0; i < 8; i++) {
		if (num&128) { 
			printf(" 1");
		} else {
			printf(" 0");
		}
		num = num << 1;
	}
}

