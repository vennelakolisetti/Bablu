#include<stdio.h>
void display1(unsigned char num);
void display2(unsigned char num);
void display3(unsigned char num);
int count1(unsigned char num);
int count2(unsigned char num);
int count3(unsigned char num);
int main()
{
    //int set = 0;
    //int clear = 0;
    unsigned char num;
    printf("Enter num\n");
    scanf("%hhd", &num);
/*    printf("\nBit representation Before\n");
    display1(num);
	printf("\n");
	display2(num);
	printf("\n");
	display3(num);
    printf("\n");*/
    count1(num);
	printf("\n");
	count2(num);
	printf("\n");
	count3(num);
    printf("\nBit representation After\n");
    display1(num);
	printf("\n");
	display2(num);
	printf("\n");
	display3(num);
    return 0;
}
int count1(unsigned char num)
{
   int set = 0;
    int clear = 0;
    int i = 0;
    while(i != 8) {
        if((num&(1<<i)) == 0) {
            clear = clear + 1;
        } else {
          set = set + 1;
        }
        i++;
    }
    printf("%d\n", set);
    printf("%d\n", clear);
    
}
int count2(unsigned char num)
{
   int set = 0;
    int clear = 0;
    int i = 0;
    while(i != 16) {
        if((num&(1<<i)) == 0) {
            clear = clear + 1;
        } else {
          set = set + 1;
        }
        i++;
    }
    printf("%d\n", set);
    printf("%d\n", clear);
    
}
int count3(unsigned char num)
{
   int set = 0;
    int clear = 0;
    int i = 0;
    while(i != 32) {
        if((num&(1<<i)) == 0) {
            clear = clear + 1;
        } else {
          set = set + 1;
        }
        i++;
    }
    printf("%d\n", set);
    printf("%d\n", clear);
    
}
void display1(unsigned char num)
{
    for (int i = 7; i >= 0; i--) {
        //if ((1 << i) & num) {
		if (num&128)  {
            printf("1");
        } else {
            printf("0");
        }
	   num = num << 1;	
        
    }
}
void display2(unsigned char num)
{
    for (int i = 15; i >= 0; i--) {
        if ((1 << i) & num) {
            printf("1");
        } else {
            printf("0");
        }

    }
}
void display3(unsigned char num)
{
    for (int i = 31; i >= 0; i--) {
        if ((1 << i) & num) {
            printf("1");
        } else {
            printf("0");
        }

    }
}
