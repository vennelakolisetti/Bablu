#include<stdio.h>
void display(unsigned char num);
unsigned char swapbits(unsigned char num);
int main()
{
	unsigned char num;
	printf("Enter num\n");
	scanf("%hhd", &num);
	display(num);
	swapbits(num);

}
unsigned char swapbits(unsigned char num)
{
	int i = 0;
	int pos1;
	int pos2;
	printf("\nEnter pos1\n");
	scanf("%d", &pos1);
	printf("\nEnter pos2\n");
	scanf("%d", &pos2);
	//while (i != 8) {
		if(((num >> pos1) & 1) == ((num >> pos2) & 1)) {
			return num;
		} else {
			num = ((1 << pos1) ^ num);
			num = ((1 << pos2) ^ num);
		}
		//i++;
	//}
	printf("%d\n", num);
	display(num);
}
void display(unsigned char num)
{
	int i;
	for(int i = 0; i < 8; i++) {
		if(num & 128) {
			printf(" 1");
		} else {
			printf(" 0");
		}
		num = num << 1;
	}
}
