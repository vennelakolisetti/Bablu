#include<stdio.h>
int main()
{
	unsigned char num;
	char arr[20];
	int i;
	printf("Enter the number:");
	scanf("%hhd", &num);
	for(i = 0; i < 8; i++) {
		if(num & 128) {
			arr[i] = 1;
		} else {
			arr[i] = 0;
		}
		num = num << 1;
	}
	for (i = 0; i < 8; i++ ) {
		printf("%d", arr[i]);
	}
	printf("\n");
	for (i = 7; i >= 0; i--) {
		printf("%d", arr[i]);
	}
	return 0;
}
