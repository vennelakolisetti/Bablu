#include<stdio.h>
void display(unsigned int num);
void clearcount(unsigned int num);
void trailcount(unsigned int num);
void leadset(unsigned int num);
void trailset(unsigned int num);
int main()
{
	unsigned int num;
	printf("Enter number\n");
	scanf("%d", &num);
	display(num);
	clearcount(num);
	trailcount(num);
	leadset(num);
	trailset(num);
	
}
void leadset(unsigned int num) 
{
	int i = 0;
	int count = 0;
	while(i != 8) {
		if(((128 << i) & num) == 1) {
			count++;
		} else {
			break;
		} 
		i++;
	}
	printf("%d\n", count);
}
void trailset(unsigned int num)
{
	int i = 0;
	int count = 0;
	while(i != 8) {
		if (((1 >> i) & num) == 1) {
			count++;
		} else {
			break;
		}
		i++;
	}
	printf("%d\n", count);
}
void trailcount(unsigned int num) 
{
	int i = 0;
	int count = 0;
   while (i != 8) {
   	if(((1 << i) & num) == 0) {
		count++;
	} else {
		break;
	}
	i++;
	//printf("\n%d", count);
   }
   printf("\n%d\n", count);
}

void clearcount(unsigned int num) 
{
	int i = 0;
   	int count = 0;	
	while( i != 8) {
		if (((128 >> i) & num) == 0) {
			count++;
		} else {
			break;
		}
		i++;
	}
	printf("\n%d\n", count);
}
void display(unsigned int num)
{
	for(int i = 0; i < 8; i++) {
		if (num & 128) {
			printf(" 1");
		} else {
			printf(" 0");
		}
		num = num << 1;
	}
}

