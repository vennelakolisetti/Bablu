// CPP program to illustrate
// default Signal Handler
#include<stdio.h>
#include<signal.h>
#include<sys/wait.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
int main()
{
	signal(SIGINT, SIG_DFL);
	while (1)
	{
		printf("hello world\n");
		sleep(1);
	}
	return 0;
}

#if 0
// CPP program to illustrate
// User-defined Signal Handler
#include<stdio.h>
#include<signal.h>

// Handler for SIGINT, caused by
// Ctrl-C at keyboard
void handle_sigint(int sig)
{
	printf("Caught signal %d\n", sig);
}

int main()
{
	signal(SIGINT, handle_sigint);
	while (1) ;
	return 0;
}
#endif
