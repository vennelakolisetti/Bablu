#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
int main()
{
	pid_t id;
	id = fork();
	if(id == -1) {
		printf("Error in fork creation\n");
		exit(1);
	}
	if(id == 0) {
		while(1) {
			printf("Hello SIGKILL\n");
			usleep(1000);
		}
	} else {
		int a = 10;
		int c = 10/ 0;
		//printf("%d", c);
		sleep(1);
		kill(id, SIGKILL);
		wait(NULL);
		printf("Hellooooo parent\n");
		printf("%d", c);
	}
}
