#include<stdio.h>
int main()
{
	int i, j;
	int rows, cols;
	printf("Enter rows and cols:");
	scanf("%d%d", &rows, &cols);
	int a[rows][cols];
	printf("Enter matrix\n");
	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	printf("transpose is\n");
	for (i = 0; i < cols; i++) {
		for (j = 0; j < rows; j++) {
			printf("%d ", a[j][i]);
		}
		printf("\n");
	}
}
	
