#include<stdio.h>
int main()
{
	FILE *fp;
	fp = fopen("add.txt", "w");
	int a;
	int b;
	int c;
	printf("Enter a\n");
	scanf("%d", &a);
   	printf(	"Enter b\n");
	scanf("%d", &b);
	c = a + b;
	printf("%d", c);
	fprintf(fp, "%d\t%d\t%d", a, b, c);
	fprintf(fp , "%d+%d=%d" , a, b, c);
//	putw(a, fp);
//	putw(b, fp);
//	putw(c, fp);
	fclose(fp);
}
