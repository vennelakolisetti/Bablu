#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 100
int main()
{
	FILE *fp1;
	FILE *fp2;
	FILE *fp3;
	fp1 = fopen("file1.txt", "w");
	fp2 = fopen("file2.txt", "w");
	fp3 = fopen("file3.txt", "w");	
	char str[SIZE];
	int i;
	printf("Enter string\n");
	fgets(str, SIZE, stdin);
	int len = strlen(str);
	printf("%d", len);
	//int total = len/3;
	while (str[i] != '\0') {
		if (i < len/3) {
			fputc(str[i], fp1);
		} else if(i >= len/3 && i <= len/2) {
			fputc(str[i], fp2);
		} else if(i >= len/2 && i <= len) {
			fputc(str[i], fp3);
		}
		i++;
	}
		fclose(fp1);
		fclose(fp2);
		fclose(fp3);
}
