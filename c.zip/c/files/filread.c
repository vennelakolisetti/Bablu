#include<stdio.h>
#include<stdlib.h>
int main()
{
	FILE *fp;
	char str[100];
	char ch;
	fp = fopen("output.txt", "r");
	while (ch = (fgetc(fp)) != EOF) {
		if(ch == ' ' && ch == '\n') {
			if (ch >= 'a' && ch <= 'z') {
				fputc(ch - 32, fp);
			}

		}
	}
	while(fgets(str, 100, fp) != NULL) {
		printf("%s", str);
	}
	fclose(fp);
	return 0;
}
