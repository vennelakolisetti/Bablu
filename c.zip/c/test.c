#include<stdio.h>
#include<stdlib.h>
#define SIZE 10
int main()
{
	char *s = "hello";
	char *p = s;
	printf("%c\t%c", p[1], s[1]);
}
#if 0
int main(int num)
{
	return (num <= SIZE && printf("%d", num) && main(num+1));
/*	if (num <= SIZE && printf("%d", num) && main(num + 1)) {
	}*/
}
#endif
#if 0
int main()
{
	int *num;
	num = (int*) malloc (0 * sizeof(int));
	//printf("%ld", sizeof(num));
	free(num);
	//printf("%ld", sizeof(num));
}
#endif
