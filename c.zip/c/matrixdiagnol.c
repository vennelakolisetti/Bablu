#include<stdio.h>
int main()
{
	int a[10][10];
	int i, j;
	int m, n;
	int sum = 0;
	printf("Enter the rows ans cols\n");
	scanf("%d %d", &m, &n);
	printf("Enter the elements of matrix\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	printf("The matrix is\n");
	for (i = 0; i < m; i++) {
		printf("\n");
		for (j = 0; j < n; j++) {
			printf("%d\t", a[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			if (i == j) {
				sum = sum+a[i][j];
			}
		}
	}
	printf("sum is :%d", sum);
	return 0;
}
