#include<stdio.h>
int main(int argc, char* argv[]) 
{
	int count;
	printf("%s", argv[0]);
	if (argc == 1) {
		printf("Error command\n");
	} else if(argc >= 2) {
		printf("number of args: %d\n", argc);
		for(count = 0; count < argc; count) {
			printf("argv[%d]: %s", count, argv[count]);
		}
		//return 0;
	}
}
