#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc, char* argv[])
{

	char ch;
	int size;
	FILE *fp;
	fp = fopen(argv[1], argv[2]);
	if (fp == NULL) {
		printf("Error open file\n");
	} else {
		printf("file opened\n");
	}
	if (argc > 3) {
		printf("command error\n");
		exit(1);
	}
	fclose(fp);
}

