#include<stdio.h>
#include<stdlib.h>
int main()
{
	FILE *fp;
	fp = fopen("input.txt", "r");
	int num = 5;
	int  i = 1;
	char ch;
	char str[100];
	while( fgets(str, 100, fp) != NULL) {
		if (i != num) {
			printf("%s", str);
		}
		i++;
	}
	fclose(fp);
}
