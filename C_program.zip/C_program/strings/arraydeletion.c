#include<stdio.h>
int main()
{
    int i,n,pos;
    printf("enter the elements you want: ");
    scanf("%d",&n);
    int arr[n];
    printf("enter the elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    
    printf("enter the position to delete:");
    scanf("%d", &pos);
    for(i=pos-1;i<n;i++)
    {
        arr[i]=arr[i+1];
    }
    for(i=0;i<n-1;i++)
    {
        printf("%d\n",arr[i]);
    }


}
