#include<stdio.h>
int main()
{
    unsigned int num,res,pos;
    printf("Enter Number: \n");
    scanf("%d",&num);
    printf("Enter Position: \n");
    scanf("%d",&pos);

    res=num|(1<<pos);

    printf("%d",res);
}
