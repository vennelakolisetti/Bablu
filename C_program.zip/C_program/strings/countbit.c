#include<stdio.h>
#define SIZE 4
int main()
{
int i,count=0,num;
//int arr[SIZE];
printf("enter the number:");
scanf("%d",&num);
for(i=SIZE-1;i>=0;i--)
{
    if(num&(1<<i))
    {
        printf("1");
    }
    else{
        printf("0");
    }
     count++;
}
printf("total count bits:%d",count);
}