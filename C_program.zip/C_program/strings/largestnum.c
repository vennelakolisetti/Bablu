#include<stdio.h>
int main()
{
    int arr[5];
    int i,temp;
    for(i=0;i<5;i++)
    {
        scanf("%d",&arr[i]);
    }
    int len1=arr[0];
    int len2=arr[1];
    if(len2>len1)
    {
        temp=len1;
        len1=len2;
        len2=temp;
    }
    for(i=2;i<5;i++)
    {
        if(arr[i]>len1){
            len2=len1;
            len1=arr[i];
        }
        else if(arr[i]>len2&& arr[i]!=len1);
        {
        len2=arr[i];
        }
    }
    printf("two largest numbers are:%d,%d",len1,len2);
    }