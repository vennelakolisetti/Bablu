#include<stdio.h>
#include<string.h>
int main()
{
    char s[50];
    int pos,i;
    printf("enter the string");
    gets(s);
    int len =strlen(s);
    printf("enter the position:");
    scanf("%d",&pos);
  //  len=pos+len; 
    for(i=pos;i<len;i++)
    {
        printf("%c",s[i]);
    }
}
