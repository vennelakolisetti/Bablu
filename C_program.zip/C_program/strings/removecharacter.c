#include<stdio.h>
#include<string.h>
int main()
{
    char s[50];
    char c;
    int i,j,len;
    printf("enter the string:");
    gets(s);
    printf("enter the char to remove:");
    scanf("%c",&c);
    len=strlen(s);
    for(i=0;i<len;i++)
    {
        if(s[i]==c)
        {
            for(j=i;j<len;j++)
            {
                s[j]=s[j+1];
            }
            len--;
            i--;
        }
    }
    printf("string after remove the char:%s",s);


}