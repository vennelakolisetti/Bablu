#include<stdio.h>
int main()
{
    int i;
    int n,pos;
    printf("enter the no of elements:");
    scanf("%d",&n);
    int arr[n];
    printf("enter the elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("enter the position you want to inserted");
    scanf("%d",&pos);
    for(i=n-1;i>=pos-1;i--)
   {
       arr[i+1]=arr[i];
         
    }
    arr[pos-1]=13;
   
    printf("final array elements:");
    for(i=0;i<=n;i++)
    {
        printf("%d\n",arr[i]);
    }
}
