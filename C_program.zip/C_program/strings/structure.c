#include<stdio.h>
int main()
{
    struct student
    {
        int id;
        char name[20];
        float points;
    };
    struct student std[3];
    struct  student *ptr=NULL;
    ptr=std;
    int i;
    for(i=0;i<3;i++)
    {
        printf("enter the employee details:%d",i);
        scanf("%d",&ptr->id);
        scanf("%s",ptr->name);
        scanf("%f",&ptr->points);
        ptr++;
    }
    ptr=std;
    for(i=0;i<3;i++)
    {
        printf("id=%d\n",std[i].id);
        printf("name=%s\n",std[i].name);
        printf("points=%f\n",std[i].points);
    }
    //display results using pointer
    for(i=0;i<3;i++)
    {
        printf("id=%d\n",ptr->id);
        printf("name=%s\n",ptr->name);
        printf("points=%f\n",ptr->points);
        ptr++;
    }

}