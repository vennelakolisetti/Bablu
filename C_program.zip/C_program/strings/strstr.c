#include<stdio.h>
#include<string.h>
int main()
{
    char s[50];
    char s1[20];
    int flag;
    int i,j;
    printf("enter the string1:");
    gets(s);
    printf("enter the string2:");
    gets(s1);
   int len1 =strlen(s);
   int len2 =strlen(s1);
   for(i=0;i<=len1-len2;i++)
   {
    for(j=i;j<i+len2;j++)
    {
        flag=1;
        if(s[j]!=s1[j-i])
        {
            flag=0;
            break;
        }
    }
    if(flag==1)  {
    break;
  }
   }
   if(flag==1){
    printf("present");
   }
   else
   {
    printf("not present");
   }
  }  
   
