#include<stdio.h>
int main()
{
    unsigned int num1,num2,sum;
    printf("Enter Number1: \n");
    scanf("%d",&num1);
    printf("Enter Number1: \n");
    scanf("%d",&num1);

    while(num2!=0)
    {
        sum=num1&num2;
        num1=num1^num2;
        num2=sum<<1;
    }
    printf("Sum: %d",num1);
    return 0;
}

