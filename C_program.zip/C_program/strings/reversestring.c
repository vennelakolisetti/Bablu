#include<stdio.h>
#include<string.h>

void revstr(char *str1)
{
    int i, temp,len;
len=strlen(str1);
for(i=0;i<len/2;i++){
    temp=str1[i];
    str1[i]=str1[len-i-1];
    str1[len-i-1]=temp;
}
}
int main()
{
    char str1[50];
    printf("enter the string:");
    gets(str1);
    printf("before the revese the string:%s",str1);
    revstr(str1);
    printf("after reverse the string:%s",str1);
}
