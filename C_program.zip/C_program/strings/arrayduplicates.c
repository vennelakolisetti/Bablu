#include<stdio.h>
int main()
{
    int i,j,k,n;
    printf("enter the no of elements :");
    scanf("%d",&n);
    int arr[n];
    printf("enter the the elements:");
     for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(arr[i]==arr[j])
            {
                printf("duplicate elements are:\n");
                printf("%d\n",arr[j]);
                 for(k=j;k<n;k++)
                {
                 arr[k]=arr[k+1];
                }
            n--;
            j--;
            }
        }
        
    }
    printf("elements after removing duplicates:");
     for(i=0;i<n;i++)
    {
        printf("%d",arr[i]);
    }

    
}