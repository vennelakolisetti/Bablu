
#include<stdio.h>
#include<string.h>
int main()
{
    char str[50];
    int i=0,count=0;
    char *ptr;
    ptr=str;
    printf("enter a string");
    scanf("%s",str);
    while(*ptr!='\0')
    {
        count++;
        ptr++; 
    }
        printf("string length: %d\n",count); 
    return 0;
}

