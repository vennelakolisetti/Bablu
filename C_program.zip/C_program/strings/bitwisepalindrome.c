#include<stdio.h>
#define SIZE 4
int main()
{
    int i,j,num,flag=0;
    int arr[SIZE];
    printf("enter the number:");
    scanf("%d",&num);

    for(i=SIZE-1;i>=0;i--)
    {
        if((1<<i)&num)
        {
            printf("1");
            arr[i]=1;
        }
        else
        {
            printf("0");
            arr[i]=0;
        }
    }
    printf("\n");
    for(i=0,j=SIZE-1;i<j;i++,j--)
    {
        if(arr[i]!=arr[j])
        {
            flag=1;
            break;
        }
    }
    if(flag==1)
    {
        printf("Not palindrome");
    }
    else{
    printf(" palindrome");
    }
    return 0;
}