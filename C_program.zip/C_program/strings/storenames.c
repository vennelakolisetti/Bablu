#include<stdio.h>
#include<stdlib.h>

void __fpurge(FILE *stream);
int main()
{
    int r=5,c=10;
    int i;
    char **names;
    names=(char **)malloc(r * sizeof(char*));
    for(i=0;i<r;i++)
    {
    names[i]=(char *)malloc(c * sizeof(char));  
    }
    for(i=0;i<r;i++)
{
printf("enter names:%d",i+1);
__fpurge(stdin);
fgets(*(names+i),c,stdin);
}
for(i=0;i<r;i++)
{
    printf("names you store:%d,%s",i+1,*(names+i));
}
return 0;
}