#include<stdio.h>
int main()
{
    int i,j,n;
    //int arr[n];
    int count=0;
    printf("enter the size:");
    scanf("%d",&n);
     int arr[n];
    for(i=0;i<n;i++)
    {
      printf("enter the elements:\n");  
      scanf("%d",&arr[i]);
    }
for(i=0;i<n;i++){
    for(j=0;j<n;j++)
    {
    if(arr[i]==arr[j]&&i!=j)
    {
        break;
    }
}
if(j==n){
    printf("unique elements are [%d]:%d\n",count,arr[i]);
    count++;
}
}
return 0;
}

