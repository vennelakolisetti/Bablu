#include<stdio.h>
int main()
{
    int i, max, n;
    printf("enter the  no of elements: ");
    scanf("%d",&n);
    int arr[n];
    printf("enter the elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    max=arr[0];
    for(i=0;i<n;i++)
    {
        if(arr[i]>max)
        {
            max=arr[i];
        }
    }
    printf("enter the max number:%d",max);
    return 0;
}