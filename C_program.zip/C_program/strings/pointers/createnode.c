#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
struct node *head=NULL;
int cnt;

void creation()
{
int n,i;
struct node *newnode;
struct node *temp=NULL;
printf("enter number of nodes:");
scanf("%d",&n);
for(i=0;i<n;i++)
{
    newnode=(struct node*)malloc(sizeof(struct node));

    printf("enter the data:");
    scanf("%d", &newnode->data);


    newnode->next=NULL;
    if(head==NULL)
    {
        head=temp=newnode; 
    }
    else{
    temp->next=newnode;
    temp=temp->next;
    }
    
}
}
void display()
{
   struct node *temp;
    if(head==NULL)
    {
        printf("list is empty");
    }

        temp=head;
    while(temp!=NULL)
    {
        printf("%d\t",temp->data);
        temp=temp->next;
             
}  
  
}

int count_fun()
{
   struct node *temp;
   int cnt=0;
   temp=head;
   while(temp!=NULL)
        {
            temp=temp->next;
            cnt++;
             
        }  
        
    printf("cnt=%d\n",cnt);
    return cnt;
        
}

void count_nodes()
{
   struct node *temp;
   int count=0;
   if(head==NULL)
    {
        printf("list is empty");
    } 

        temp=head;
    while(temp!=NULL)
    {
        temp=temp->next;
        count++;
             
    }  
    
    printf("Number of Nodes present in Linked List=%d",count);
}

void insertatbeg()
{
    struct node *prevnode;
    prevnode=(struct node*)malloc(sizeof(struct node));
    printf("enter the data to insert:");
    scanf("%d",&prevnode->data);
    prevnode->next=head;
    head=prevnode;
}

void insertatpos()
{
    int pos,i=1;
    struct node *addnode;
    struct node *temp=head;
    addnode=(struct node*)malloc(sizeof(struct node));
    printf("enter the position:");
    scanf("%d",&pos);
    printf("enter the data:");
    scanf("%d",&addnode->data);
    cnt = count_fun();
     
    if(pos>cnt)
    {
        printf("Invalid Position\n");
    }
    else if(head==NULL)
    {
        head=temp=addnode;
        addnode->next=NULL;
    }
   
    else
    {
    while(i<pos-1)
    {
        temp=temp->next;
        i++;
    }
        addnode->next=temp->next;
        temp->next=addnode;
    }
}
void insertatend()
{
    struct node *temp, *newnode;
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("enter the data:");
    scanf("%d",&newnode->data);
    newnode->next=NULL;
    if(head==NULL)
    {
        head=newnode;
    }
    else
    {
     temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=newnode;
    }
}



void main()
{
    
    int choice=0;
    while(choice!=7)
    {
        printf("Enter Choice: \n1.Creation\n2.Insert First\n3.Insert at Position\n4.Display\n5.Count Nodes\n6.insertatend\n7.Exit\n");
        scanf("%d",&choice);
        switch (choice)
        {
        case 1: creation();
            break;
        case 2:  insertatbeg();
            break;
        case 3: insertatpos();
            break;
        case 4: display();
            break;
        case 5: count_fun();
            break;
        case 6: insertatend();
            break;
        case 7: exit(0);
            break;

        default:
        printf("Invalid Choice: \n");
        
        }
    } 

}
    



