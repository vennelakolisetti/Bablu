#include<stdio.h>
int main()
{
    int i,key;
    int arr[10];
    printf("enter the elements");
    for(i=0;i<10;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("element to be searched:");
    scanf("%d",&key);
    for(i=0;i<10;i++)
    {
        if(arr[i]==key)
        {
            printf("element is found");
        }
    }
}