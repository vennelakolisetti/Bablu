#include<stdio.h>
int main()
{
    int n,i;
    int *ptr;
    scanf("%d",&n);
    ptr=&n;
    for(i=1;i<=10;i++)
    {
         printf("%d*%d=%d\n",n,i,*ptr*i);
    }
   // printf("%d*%d=%d\n",n,i,mul);
}