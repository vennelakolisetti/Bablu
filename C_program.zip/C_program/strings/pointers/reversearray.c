#include<stdio.h>
int main()
{
    int i,n;
    int arr[100];
    int *ptr;
    printf("enter the no of elements");
    scanf("%d",&n);
    ptr=&arr;
    printf("enter the elements:");
    for(i=0;i<n-1;i++)
    {
        scanf("%d\n",ptr);
        ptr++;
    }
       ptr=arr;
    ptr=&arr[n-1];
    printf("elemts after reverse");
    for(i=n-1;i>=0;i--)
    {
        printf("%d\n",*(ptr));
        ptr--;
    }
    return 0;
}