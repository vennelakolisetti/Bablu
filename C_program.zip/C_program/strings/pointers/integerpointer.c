#include<stdio.h>
int addnum(int *,int *);
int main()
{
int a=10,b=20,c;
c=addnum(&a,&b);
printf("result=%d",c);
}
int addnum(int *p1,int *p2)
{
    int sum;
    sum=*p1+*p2;
    return sum;
}


