#include<stdio.h>
void swap(int*,int*);

int main()
{
    int a,b;
    printf("enter the  first value:");
    scanf("%d",&a);
    printf("enter the second value");
    scanf("%d",&b);
    swap(&a,&b);
    printf("after swapping first value is:%d",a);
    printf("after swapping second value is:%d",b);
}
void swap(int *p1 ,int *p2)
{
    *p1=*p1+*p2;
    *p2=*p1-*p2;
    *p1=*p1-*p2;

}