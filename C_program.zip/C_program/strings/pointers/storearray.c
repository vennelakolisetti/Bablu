#include<stdio.h>
int main()
{
    int arr[5];
    int *p1;
    p1=&arr[0];
    for(int i=0;i<5;i++)
    {
        printf("enter the number");
        scanf("%d",p1+i);
    }
    printf("elements in array:");
    for(int i=0;i<5;i++)
    {
        printf("%d",*p1);
        p1++;
    }

    
}