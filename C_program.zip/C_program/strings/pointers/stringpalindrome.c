#include<stdio.h>
int main()
{
    char str[100];
    char *ptr1,*ptr2;
    printf("enter the string:");
    scanf("%s",str);
    ptr1=str+strlen(str)-1;
    ptr2=str;
    while(ptr1>=ptr2)
    {
       if(*ptr1==*ptr2)
       {
        ptr1--;
        ptr2++;
       }
        else
        {
            break;
        }
    }
    if(ptr2>ptr1)
    printf("string is palindrome");
    else
    printf("string is not palindrome");
}