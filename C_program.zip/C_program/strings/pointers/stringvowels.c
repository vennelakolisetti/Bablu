#include<stdio.h>
#include<string.h>
int count(char *);
int main()
{
    char str[15];
   // int cntv,cntc;
    printf("enter the string");
    scanf("%s",str);
    count(str);
    return 0;
   // printf("vowels=%d,consonants=%d",cntv,cntc);
}
int count(char *p)
{ 
    int cntv=0,cntc=0;
    while(*p!='\0')
    {
        if(*p=='A'||*p=='E'||*p=='I'||*p=='O'||*p=='U'||*p=='a'||*p=='e'||*p=='i'||*p=='o'||*p=='u')
        {
            cntv++;
        }
        else
        {
            cntc++;
        }
        p++;
    }
    printf("\nvowels=%d,consonants=%d",cntv,cntc);
}

    


