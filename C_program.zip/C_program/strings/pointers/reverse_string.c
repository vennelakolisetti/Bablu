#include<stdio.h>
#include<string.h>
char reverse_str(char[], char[]);
int main()
{
    char str1[30];
    char str2[30];
    printf("enter the string:");
    scanf("%s",str1);
    reverse_str(str1,str2);
   printf("string after reverse:%s",str2);
}

char reverse_str(char str1[], char str2[])
{   
    char *p1,*p2;
    p1=str1+strlen(str1)-1;
    p2=str2;
    while(p1>=str1)
    {
       *p2=*p1;
        p2++;
        p1--;
    }
    *p2='\0';

    return str2;
    
     
    
}


