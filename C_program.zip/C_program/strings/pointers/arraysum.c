#include<stdio.h>
//#include<stdlib.h>

int arrsum(int *ptr)
{  
    
    int i,sum=0;
    for(i=0;i<5;i++)
    {
        sum=sum + *ptr;
        ptr++;
    }
    printf("Sum:%d\n",sum);
    return 0;
}
int main()
{
    
    int i;    
   // printf(" no of elements enter the elements;");
   // scanf("%d",&n);
    int arr[5];
    for(i=0;i<5;i++)
        {
            scanf("%d",&arr[i]);
        
        }
    arrsum(arr);
    return 0;
}
