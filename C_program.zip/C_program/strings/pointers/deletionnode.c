#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
struct node *head;


void creation()
{
int n,i;
struct node *newnode;
struct node *temp=NULL;
printf("enter number of nodes:");
scanf("%d",&n);
for(i=0;i<n;i++)
{
    newnode=(struct node*)malloc(sizeof(struct node));

    printf("enter the data:");
    scanf("%d", &newnode->data);


    newnode->next=NULL;
    if(head==NULL)
    {
        head=temp=newnode;
    }
    else{
    temp->next=newnode;
    temp=temp->next;
    }
    
}
}
void display()
{
   struct node *temp;
    if(head==NULL)
    {
        printf("list is empty");
    }

        temp=head;
    while(temp!=NULL)
    {
        printf("%d\t",temp->data);
        temp=temp->next;
             
}  
  
}
void deleteatbeg()
{
    struct node *temp;
   if(head==NULL)
   {
    printf("list is empty");
   } 
   temp=head;
   head=head->next;
   free(temp); 
}

void deleteatend()
{
    struct node *temp, *newnode;
    temp=head;
    while(temp->next!=NULL)
    {
        newnode=temp;
        temp=temp->next;
    }
    if(temp==head)
    {
        free(head);
        printf("list is empty");
    }
    else
    {
        newnode->next=NULL;
      
    }
    free(temp);
}
void deleteatpos()
{
    struct node *temp,*newnode;
    int pos,i=1;
    printf("enter the position:");
    scanf("%d",&pos);
    while(i<pos-1)
    {
        temp=temp->next;
    }
    newnode=temp->next;
    temp->next=newnode->next;
    free(newnode);

}

void reverselist()
{
    struct node *prevnode=NULL,*currentnode,*nextnode;
    currentnode=nextnode=head;
    while(nextnode!=NULL)
    {
        nextnode=nextnode->next;
        currentnode->next=prevnode;
        prevnode=currentnode;
        currentnode=nextnode;
    }
    head=prevnode;
    display();

}

void main()
{
    
     int choice=0;
    while(choice!=7)
    {
        printf("Enter Choice: \n1.Creation\n2.diplsy \n3.delete at beg\n4.delete at end\n5.delete at pos\n6.reverselist\n7.Exit\n");
        scanf("%d",&choice);
        switch (choice)
        {
        case 1: creation();
            break;
        case 2:  display();
            break;
        case 3: deleteatbeg();
            break;
        case 4: deleteatend();
            break;
        case 5: deleteatpos();
            break;
        case 6: reverselist();
            break;
        case 7: exit(0);
            break;

        default:
        printf("Invalid Choice: \n");
        
        }
    } 

}
    




