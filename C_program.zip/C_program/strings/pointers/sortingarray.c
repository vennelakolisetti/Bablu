#include<stdio.h>
int main()
{
    int i,j,n,temp,arr[100];
    int *p;
    p=&arr[0];
   // p=arr;
    printf("enter the no of elements:");
    scanf("%d",&n);
    printf("enter the elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",p+i);
    }

    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(*(p+i)>*(p+j))
            {
                temp=*(p+i);
                *(p+i)=*(p+j);
                *(p+j)=temp;
            }
        }
    }
    printf("After Reverse: \n");
    for(i=0;i<n;i++)
    {
        printf("%d\n",*p);
        p++;
    }

}