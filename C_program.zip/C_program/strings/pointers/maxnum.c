#include<stdio.h>
int maxnum(int *,int *);
int main()
{
    int a,b;
    printf("enter the first number:");
    scanf("%d",&a);
    printf("enter the second number:");
    scanf("%d",&b);
    maxnum(&a,&b);
    return 0;
}
int maxnum(int *p1,int *p2)
{
    if(*p1>*p2)
    {
        printf("the greatest number is %d",*p1);
    }
    else{
        printf("the greatest number is %d",*p2);
    }
    return 0;
}