#include<stdio.h>
#include<stdlib.h>
int main()
{
    int *arr,n,i;
    printf("no of elements:");
    scanf("%d",&n);
    arr=(int *)malloc(n * sizeof(int));
    if(arr==NULL)
    {
        printf("memory not allocated");
    }
    for(i=0;i<n;i++)
    {
        printf("enter the elements:");
        scanf("%d",arr+i);

    }

    for(i=0;i<n;i++)
    {
        if((*arr)<(*(arr+i)))
        {
            *arr=*(arr+i);
        }
    }
    printf("largest number is:%d",*arr);

}


