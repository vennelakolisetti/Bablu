#include<stdio.h>
int main()
{
   char str[50],ch;
   int count=0;
   printf("enter the string:");
   fgets(str,50,stdin);
   printf(" enter the character:");
   scanf("%s",&ch);
   for( int i=0;str[i]!='\0';i++)
   {
    if(str[i]==ch)
        count++;
   }
   printf("the frequency of string: %d",count);
   return 0;
}