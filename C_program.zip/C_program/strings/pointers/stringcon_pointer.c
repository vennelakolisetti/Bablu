#include<stdio.h>
char stringconcate(char[],char[]);
int main()
{
    char str1[30],str2[30];
    printf("enter the first string:");
    scanf("%s",str1);
    printf("enter the second string:");
    scanf("%s",str2);
    stringconcate(str1,str2);
    printf("string after concate:%s",str1);
    return 0;
}
char stringconcate(char str1[],char str2[])
{
    char *p1,*p2;
    p1=str1;
    p2=str2;
    while(*p1!='\0')
    {
        p1++;
    }
    while(*p2!='\0')
    {
       *p1=*p2;
        p2++;
        p1++;
    }
    *p2='\0';
    return str1;

}