#include<stdio.h>
#include<string.h>
int main()
{
    char str1[100];
    char str2[100];
    int i,len;

    printf("enter the string:");
    scanf("%s",str1);
   // len=strlen(str1);
    for(i=0;str1[i]!='\0';i++)
    {
    str2[i]=str1[i];
    }
str2[i]='\0';
    printf("after copy the string:%s",str2);
}