#include <iostream>
using namespace std;
class DemoA {
public:
	int get_a(void);
	void set_a(int val);
private:
	int a;
};
int DemoA::get_a(void) {
	return a;
}
void DemoA::set_a(int val) {
	a = val;
}
int main()
{
	DemoA a;
	a.set_a(10);
	cout << "val of a is: " << a.get_a() <<endl;
	//cout << "val of a is: " << a.set_a(10) <<endl;
	return 0;
}
