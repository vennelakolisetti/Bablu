#include <iostream>
using namespace std;
struct Length {
private:
	int feet;
	float inch;
public:
	void set_feet(int x) {
		feet = x;
	}
	int get_feet() {
		return feet;
	}
	void set_inch(float y) {
		inch = y;
	}
	float get_inch() {
		return inch;
	}
};
int main()
{
	Length d1, d2;
	int a;
	float b;
	cout << "Enter a and b values\n";
	cin >> a;
	cin >> b;
	d1.set_feet(a);
	//d1.set_feet(10);
	//d1.set_feet = 10;
	d1.get_feet();
	d2.set_inch(b);
	d2.get_inch();
	cout << "feet is : " << d1.get_feet() << endl;
	cout << "inch is : " << d2.get_inch() << endl;
	return 0;
}
