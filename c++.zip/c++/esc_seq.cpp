// To display hexadecimal integer literals and
// decimal integer literals.
//
#include <iostream>
using namespace std;
int main()
{
	cout << "\nThis is\t a string\n"
	"with \"many\" escape sequences!\n" << endl;
	return 0;
}

