#include <iostream>
using namespace std;
class Sample {
	public:
		//int a;
		virtual void fun1() = 0;
		virtual void fun2() = 0;
};
class NewSample : public Sample {
	public:
		void fun1() {
			cout << "New1 fun1() " << endl;
		}
		void fun2() {
			cout << "New1 fun2() " << endl;
		}
};
class NewSample1 : public Sample {
	public:
		void fun1() {
			cout << "New2 fun1() " << endl;
		}
		void fun2() {
			cout << "New2 fun1() " << endl;
		}
};
class NewSample2 : public Sample {
	public:
		void fun1() {
			cout << "New3 fun1() " << endl;
		}
		void fun2() {
			cout << "New3 fun2() " << endl;
		}
};
int main() {
	Sample *s = new NewSample();
	s->fun1();
	s->fun2();
	s = new NewSample1();
	s->fun1();
	s->fun2();
	s = new NewSample2();
	s->fun1();
	s->fun2();
	return 0;
}

