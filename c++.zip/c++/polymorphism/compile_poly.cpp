#include <iostream>
using namespace std;
class sample {
	public:
		int add() {
			string str = "Iam";
			int a = 10;
			cout << str << " " << a << endl;
		}
		int add(int a, int b) {
			return a + b;
		}
};
int main() {
	sample s;
	s.add();
	cout << s.add(10, 20) << endl;
	return 0;
}
