#include <iostream>
using namespace std;
class sample {
	public:
		sample test();
		sample display();
		sample get();
};
sample sample::test() {
	cout << "Function 1" << endl;
	return *this;
}
sample sample::display() {
	cout << "I am display " << endl;
	return *this;
}
sample sample::get() {
	cout << "I am get function " << endl;
	return *this;
}
int main() {
	sample s;
	s.test().display().get();
	return 0;
}
