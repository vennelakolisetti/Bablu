#include <iostream>
using namespace std;
class calc {
	private:
		int a,b;
	public:
		calc() {
			cout << "Enter a value " << endl;
			cin >> a;
			cout << "Enter b value " << endl;
			cin >> b;
			cout << "Contructor called " << endl; 
		}
		calc &add () {
			cout << "Add is : " << a + b << endl;
			return *this;
		}
		calc &sub () {
			cout << "sub is :" << a - b << endl;
			return *this;
		}
		calc &mul() {
			cout << "mul is :" << a * b << endl;
			return *this;
		}
		calc &divide() {
			if (b == 0) {
				throw "Divide by zero error";
			} else {
				cout << "Divide is : " << a/b << endl;
				return *this;
			}
		}
		~calc() {
			cout << "Destructor called "<< endl;
		}
		
};
int main()
{
	calc c;
	c.add().sub().mul().divide();
	return 0;
}
