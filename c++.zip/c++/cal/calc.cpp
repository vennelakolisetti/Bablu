#include <iostream>
#include <stdlib.h>
using namespace std;
int main()
{
	int a, b;
	int choice;
	cout << "Enter a and b values: " << endl;
	cin >> a >> b;
	cout << "Enter choice: " << endl;
	cout << "1.Addition\t2.subtarction\t3.Multiplication\t4.Division\t5.Exit" << endl;
	cin >> choice;
	switch(choice) {
		case 1: cout << "Addition is : " << a + b << endl;
				break;
		case 2: cout << "subtraction is : " << a - b << endl;
				break;
		case 3: cout << "Multipliaction is : " << a * b << endl;
				break;
		case 4: cout << "Divison is : " << a % b << endl;
				break;
		case 5: exit(1);
				break;
		Default: cout << "Inavlid input ";
	}
	return 0;
}
