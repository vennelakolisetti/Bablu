#include <iostream>
#include<limits>
//#include<cmath>
using namespace std;
class calculator {
	public:
		double c;
		double a;
		double b;
		calculator () {
			cout << "Enter a and b value" << endl;
			cin >> a >> b;
			while(1) {
				if(cin.fail()) {
					cin.clear();
					cin.ignore(numeric_limits <streamsize>::max(),'\n');
					cout<< "You have entered wrong input" <<endl;
					cin >> a >> b;
				}	
				if (!(cin.fail())) {
					break;
				}
				
			}
		}
		void virtual dis(){
			cout << "Display" << endl;
		}
		double virtual add() {
			cout << "add" << endl;
			return 0;
		}
		double virtual sub() {
			cout << "sub" << endl;
			return 0;
		}
		double virtual dive() {
			cout << "divide " << endl;
			return 0;
		}
		double virtual mul() {
			cout << "Multiply " << endl;
			return 0;
		}		
};
class addition : public calculator {
	public :
		double add() {
			c = a + b;
			return 0;
		}
		void dis() {
			cout << c << endl;
		}
};
class substitue : public calculator {
	public:
		double sub() {
			c = a - b;
			return 0;
		}
		void dis() {
			cout << c << endl;
		}
};
class divide: public calculator {
	public:
		double dive() {
			c = a / b;
			if (b == 0) {
				cout << "Can not divide by Zero " << endl;
			} else {
				cout << c << endl;
			}
			return 0;
		}
};
class multiply : public calculator {
	public:
		double mul() {
			c = a * b;
			return 0;
		}
		void dis() {
			cout << c  << endl;
		}
};
int main() 
{
	int ch;
	//int num = 1;
	calculator *c;
	//c = new calculator();
	cout << "Enter your choice " << endl;
	cout << "1.+\t2.-\t3./\t4.*\t5.exit" << endl;
	cin >> ch;
	//while(num) {
		switch (ch) {
			case 1: 
				  c = new addition();
			  	  c->add();
			  	  c->dis();
			  	  break;
			case 2:
			  	  c = new substitue();
			  	  c->sub();
			      c->dis();
			      break;
			case 3:
			  	  c = new divide();
			  	  c->dive();
			  	  break;
			case 4: 
			  	  c = new multiply();
			  	  c->mul();
				  c->dis();
			      break;
			case 5:
				  exit(1);
				  break;
			default :
			  		cout << "Invalid input " << endl;	
					break;
		}

		//cout << "1.continue\t 0.Exit" << endl;
		//cin >> num;
	//}
	return 0;
}
