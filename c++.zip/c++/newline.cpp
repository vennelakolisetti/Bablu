#include <iostream>
using namespace std;
int main()
{
	cout << "hello\n" "ok\n" "bye\n" "loves" << endl;
	return 0;
}
