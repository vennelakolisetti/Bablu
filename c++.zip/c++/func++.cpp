#include <iostream>
using namespace std;
int fun1(int, int);
int fun2(int, int);
int fun3(int, int);
int main()
{
	cout << "Iam main func\n";
	int a, b;
	cout << "Enter a, b valuse\n";
	cin >>  a, b;
	cout << "%d", fun1(a, b);
	//iun2(a, b);
	cout << "%d", fun2(a, b);
	//fun3(a, b);
	cout << "%d", fun3(a, b);
	return 0;
}
int fun1(int a, int b)
{
	int c = a + b;
	return c;
}
int fun2(int a, int b)
{
	int c = a * b;
	return c;
}
int fun3(int a, int b)
{
	int c = a/b;
	return c;
}
