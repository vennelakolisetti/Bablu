#include <iostream>
using namespace std;

class demo {
	public:
		int age;
		string s;
		float sal;
};
int main()
{
	demo d1, d2, d3;
	//d1.age(20);
	d1.age = 20;
	d2.s = "Bablu";
	d3.sal = 11.11;
	//d3.sal(12000.00);
	cout << "Age of person is : " << d1.age << endl;
	cout << "Name of person is : " << d2.s << endl;
	cout << "salary of person is : " << d3.sal << endl;
	return 0;
}

