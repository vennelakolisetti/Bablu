#include <iostream>
using namespace std;
class Rectangle {
	public:
		int a;
		int b;
		int area() {
			return a * b;
		}
		int rect() {
			return 1/2 + (a * b);
		}
};

int main()
{
	Rectangle r1, r2;
	cout << "Enter a value for area " << endl;
	cin >> r1.a ;
	cout << "Enter b value for area " << endl;
	cin >> r1.b;
	cout << "Enter a value for Rectangle" << endl;
	cin >> r2.a;
	cout << "Enter b value for Rectangle " << endl;
	cin >> r2.b;
	cout << "Area a is :" << r1.area() << " " << "Area b is : " << r1.rect() << endl;
	cout << "Rectangle a is : " << r2.area() << " " << "Rectangle b is:" << r2.rect() << endl;
	return 0;
}
