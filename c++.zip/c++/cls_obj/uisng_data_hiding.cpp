#include <iostream>
using namespace std;
class sample {
	private:
		int a;
		int b;
	public:
		void lengthset(int n) {
			if (n >= 0) {
				a = n;
			} else {
				a = 0;
				cout << "Can not assign a negative value: " << endl;
			}
		}
		void breadthset(int n) {
			if (n >= 0) {
				b = n;
			} else {
				b = 0;
				cout << "can not assign a negative value: " << endl;
			}
		}
		int lengthget() {
			return a;
		}
		int breadthget() {
			return b;
		}
		int area() {
			return a*b;
		}
		int rect() {
			return 2*(a+b);
		}
};
int main()
{
	sample s1, s2;
/*	cout << "Enter a value: "<< endl;
	cin >> s1.lengthget();
	cout << "Enter b value: "<< endl;
	cin >> s1.breadthget();
	cout << "Enter a value: " << endl;
	cin >> s2.lengthget();
	cout << "Enter b value: " << endl;
	cin >> s2.breadthget();*/
	//lengthset(s1.lengthget());
	//breadthset(s1.breadthget());
	//lengthset(s2.lengthget());
	//breadthset(s2.breadthget());
	s1.lengthset(10);
	s1.breadthset(20);
	s2.lengthset(30);
	s2.breadthset(40);
	cout << s1.area() << endl;
	cout << s1.rect() << endl;
	cout << s2.area() << endl;
	cout << s2.rect() << endl;
	return 0;
}

