#include <iostream>
using namespace std;
class Rectangle {
	public:
		int a;
		int b;
		int area() {
			return a * b;
		}
		int rect() {
			return 1/2 + (a * b);
		}
};

int main()
{
	//Rectangle r1, r2;
	Rectangle *p1, temp ; // Inside stack
	p1 = &temp;
	Rectangle *p2 = new Rectangle();
	cout << "Enter a value for area " << endl;
	cin >> p1->a ;
	cout << "Enter b value for area " << endl;
	cin >> p1->b;
	cout << "Enter a value for Rectangle" << endl;
	cin >> p2->a;
	cout << "Enter b value for Rectangle " << endl;
	cin >> p2->b;

	cout << "Area a is :" << p1->area() << " " << "Area b is : " << p1->rect() << endl;
	cout << "Rectangle a is : " << p2->area() << " " << "Rectangle b is:" << p2->rect() << endl;
	return 0;
}
