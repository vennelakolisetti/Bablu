// C++ Program to demonstrate the
// fucntioning of a friend class
#include <iostream>
using namespace std;

class sample {
private:
	int private_variable;

protected:
	int protected_variable;

public:
	sample()
	{
		private_variable = 10;
		protected_variable = 99;
	}

	// friend class declaration
	friend class demo;
};

// Here, class demo is declared as a
// friend inside class sample Therefore,
// demo is a friend of class sample. Class demo
// can access the private members of
// class sample
class demo {
public:
	void display(sample& obj)
	{
		cout << "The value of Private Variable = "
			<< obj.private_variable << endl;
		cout << "The value of Protected Variable = "
			<< obj.protected_variable;
	}
};

// Driver code
int main()
{
	sample s;
	demo d;

	d.display(s);
	return 0;
}

