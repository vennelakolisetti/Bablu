#include <iostream>
#include <cstring>
using namespace std;
int mystring(string name);
int check();
int mystring(string name) {
	int i;
	for (i = 0; i  < name.length(); i++) {
		if (name[i] >= '0' && name[i] <= '9') {
			return 1;
		} else {
			return 0;
		}
	}
	return 0;
}
int check(string name)
{
	int i;
	if (mystring(name) == 1) {
		cout << "Number " << endl;
	} else {
		cout << "string " << endl;
	}
	return 0;
}
int main()
{
	string name;
	int i = 0;
	cout << "Enter data" << endl;
	cin >> name;
	//mystring(name);
	check(name);
	return 0;
}

