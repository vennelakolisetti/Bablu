#include <iostream>
using namespace std;

class Base
{
    private:
        int a;
    protected:
        int b;
    public:
        int c;

        void funBase ()
        {
            a = 10;
            b = 20;
            c = 30;
        }
};

class Derived:public Base
{
    public:
        void funDerived ()
        {
            a = 21;
            b = 22;
            c = 23;
        }
};

int main()
{
    Base b;
    b.a = 10;
 //   b.b = 5;
    b.c = 20;
}
/*#include <iostream>
using namespace std;
class Base
{
    private:
        int a;
    protected:
        int b;
    public:
        int c;
    void funBase()
    {
        a = 10;
        b = 20;
        c = 30;
    }
};
class Derived : public Base

{
    public:
        fundDerived ()
        {
            a = 1;
            b = 2;
            c = 3;
        }
};
int main(){
    Base x;
	Derived y;
   // x.a = 21;
    //d.b; 
    x.c = 23;
	cout << x.c << endl;
	//cout << d.b << endl;
	//cout << x.a << endl;
}*/
