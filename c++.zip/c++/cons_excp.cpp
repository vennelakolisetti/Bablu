#include <iostream>
using namespace std;
class Your;
class My
{
    private:
    int x;
    protected:
    int y;
    public:
    int z;
    friend Your;
};
class Your
{
    public:
    My m;
    void Fun()
    {
        m.x = 10;
        m.y = 20;
        m.z = 30;
        cout << "X = " << m.x << endl;
        cout << "Y = " << m.y << endl;
        cout << "Z = " << m.z << endl;
    }
};
int main()
{
    Your obj;
    obj.Fun ();
    return 0;
}
