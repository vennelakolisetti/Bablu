#include <iostream>
using namespace std;
struct var1 {
	char ch;
	int i;
	float f;
};
class var2 {
	//char ch;
	//int i;
	//float f;
};
int main()
{
	cout << sizeof(var1) << endl << sizeof(var2) << endl;
	return 0;
}
