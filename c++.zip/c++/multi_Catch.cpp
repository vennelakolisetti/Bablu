#include <iostream>
//#include<conio.h>
using namespace std;

int main()
{
    int arr[3] = { -1, 2 };
    for (int i = 0; i < 2; i++)
    {
        int num = arr[i];
        try
        {
            if (num > 0)
                // throwing numeric value as exception
                throw 1;
            else
                // throwing a character/string as exception
                throw 'a';
        }
        catch (int ex) // to catch numeric exceptions
        {
             cout << "Integer Exception" << endl;
        }
        catch (char ex) // to catch character/string exceptions
        {
             cout << "Character Exception" << endl;
        }
    }
    return 0;
}
