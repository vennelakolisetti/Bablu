//: C13:MallocClass.cpp
// Malloc with class objects
// What you'd have to do if not for "new"
//#include "../require.h"
#include <cstdlib> // malloc() & free()
#include <cstring> // memset()
#include <iostream>
using namespace std;
class Obj {
  int i, j, k;
  enum { sz = 100 };
  //string str = "hello" ;
  char buf[sz] = " hello Bablu";
public:
  void initialize() { // Can't use constructor
    cout << "initializing Obj" << endl;
    i = j = k = 0;
	cout << i << j << k << endl;
    //memset(buf, 0, sz);
	cout << buf << endl;
  }
  void destroy() const { // Can't use destructor
    cout << "destroying Obj" << endl;
	i//cout << str << end;
  }
};

int main() {
  Obj* obj = (Obj*)malloc(sizeof(Obj));
  //require(obj != 0);
  obj->initialize();
  // ... sometime later:
  obj->destroy();
  delete obj;
  //free(obj);
} 
