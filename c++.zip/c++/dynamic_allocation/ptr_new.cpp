#include <iostream>
using namespace std;
int main()
{
	int *ptr;
	int size;
	cout << "Enter size of array " << endl;
	cin >> size;
	ptr = new int[size];
	//cout << "Enter elements into arrat " << endl;
	for (int i = 0; i < size; i++) {
	//	cin >> ptr[i];
		ptr[i] = i;
	}
	cout << "Elements are " << endl;
	for (int i = 0; i < size; i++) {
		cout << ptr[i] << endl;
	}
	delete ptr;
	return 0;
}

#if DQUES==1
#include <iostream>
using namespace std;
int main()
{
	int *ptr;
	ptr = new int[10];
	for (int i = 0; i < 10; i++) {
		*(ptr + i ) = i;
	}
	for (int i = 0; i < 10; i++) {
		cout << *(ptr + i) << endl;
	}
	return 0;
}
#endif
