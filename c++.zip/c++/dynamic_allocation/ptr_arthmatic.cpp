#include <iostream>
using namespace std;
int main()
{
	int arr[5] = {1,2,3,4,5};
	int *ptr1 = arr;
	int *ptr2 = &arr[3];
	cout << "Address of Each Element in an array " << endl;
	for (int i = 0; i < 5; i++ ) {
		cout << arr + i << endl;
	}
	cout << "Operations on pointer array " << endl;
	ptr1++;
	cout << "ptr1:++ " << ptr1 << endl;
	ptr1--;
	cout << "ptr1:--" << ptr1 << endl;
	ptr1 = ptr1 - 2;
	cout << "ptr1 = ptr1 - 2 :" << ptr1 << endl;
    ptr1 = ptr1 + 2;
	cout << "ptr1 = ptr1 + 2 : " << ptr1 << endl;
	int ptr = ptr1 - ptr2;
	cout << "ptr = ptr1 - ptr2 :" << ptr << endl;
	//ptr2 = ptr2/2;
	cout << "ptr2 = ptr2/2 : " << ptr2 << endl;
	return 0;
}
