#include <iostream>
using namespace std;
char *get();
int main()
{
	cout <<"I am main function " << endl;
	cout << get() << endl;
	
	return 0;
}
char *get()
{
	char c[] = "hello";
	//return c;
	cout << c << end;
}
