#include <iostream>
using namespace std;
int main()
{
	int arr[] = {1, 2, 3, 4, 5};
	int *ptr =  arr;
	*ptr = 6;
	arr[1] = 10;
	ptr[2] = 15;
	*(ptr + 3) = 20;
	ptr += 1;
	//arr += 1;
	//for (int i = 0; i < 5; i++) {
	//	*ptr++ *= 3;
	//}
	for (int i = 0; i < 5; i++) {
		cout << arr[i] << endl;
	}
	for (int i = 0; i < 5; i++) {
		cout << *(ptr +  i) << endl;
	}
	return 0;
}
