#include <iostream>
using namespace std;
int fun1(int num);
int main()
{
	int num;
	num = 10;
	cout << num << endl;
	fun1(num);
	cout << num << endl;
	return 0;
}
int fun1(int num)
{
	num = 20;
	cout << num << endl;
	return num;
}	
