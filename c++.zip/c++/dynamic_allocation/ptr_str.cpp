#include <iostream>
using namespace std;
int main()
{
	char *str = "Hello World";
	cout << str << endl;

}
