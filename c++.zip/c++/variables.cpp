#include<iostream>
using namespace std;
int var_global;
int var_global_intialized = 10;
int main()
{
	char ch('M');
	cout << "var1: " << var_global << endl;
	cout << "var2: " << var_global_intialized << endl;
	cout << "var3: " << ch << endl;
	int s;
	int n = 10;
	s = n + 5;
	cout << "sum is: " << s << endl;
	return 0;
}

