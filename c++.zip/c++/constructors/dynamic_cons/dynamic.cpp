#include <iostream>
#define SIZE 50
using namespace std;
class sample {
	private:
		char *name;
	public:
		sample() {
			name = new char[SIZE];
			name = "Hello Bablu";
			cout << "name is : " << name << endl;
		}
		~sample() {
			cout << "Deconstructor called " << endl;
		}
};
int main()
{
	
	sample s1;
	return 0;
}
