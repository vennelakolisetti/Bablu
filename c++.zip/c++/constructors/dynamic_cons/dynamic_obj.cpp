#include <iostream>
using namespace std;
class sample {
	private:
		int* num;
	public:
		sample() {
			//default constructor
			num = new int;
			*num = 0;
			cout << "Default constructor is called : " << *num << endl;
		}
		sample(int n) {
			// parameterized constructor
			num = new int;
			*num = n;
			cout << "Parameterized constructor called : " << *num << endl;
		}
		~sample() {
			cout << "Deconstructor called : " << *num << endl;
			delete num;
		}
};
int main() {
	sample *s1 = new sample();
	sample *s2 = new sample(21);
	delete s1;
	delete s2;
	return 0;
}
