#include <iostream>
using namespace std;
class sample {
	public:
		sample() {
			//default const
			cout << "Default constructor called " << endl;
		}
		sample(int num) {
		//parameterized constructor
		cout << "parametrized constructor called " << num << endl;
	}
};			
int main() {
	sample *s1 = new sample();
	cout << endl;
	sample *s2 = new sample(21);
	return 0;
}
