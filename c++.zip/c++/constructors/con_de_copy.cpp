#include <iostream>
using namespace std;
class Rectangle
{
    public:
        int length = 10;
        int breadth = 20;
    public:
    Rectangle()
	//Rectangle();
    {
        cout << length + 5 << endl;
        cout << breadth + 5 << endl;
    }
    Rectangle(int a, int b) 
    //Rectangle(int a, int b);
	{
    	  length = a;
          breadth =b;
       
    }
	Rectangle(Rectangle &rect) 
	//Rectangle(Rectangle &rect);
	{
		length = rect.length;
		breadth = rect.length;
	}
    void Display()
	//void Display();
    {
   	  	cout << "Length: " << length << " Breadth: " << breadth << endl;
    }
    void fun1()
	//void fun1();
    {
        cout << length << endl;
    }
};
/*Rectangle::Rectangle() 
{
    cout << "Hello i am defualt" << endl;
}
Rectangle::Rectangle(int a, int b) 
{
    a = 1;
    b = 2;
    length = a;
    breadth = b;
    
}
Rectangle::Rectangle(Rectangle &rect) 
{
    length = rect.length;
    breadth = rect.breadth;
}
void Rectangle::Display()
{
	cout << "Length: " << length << " Breadth: " << breadth << endl;
}
void Rectangle::fun1() 
{ 
	cout << length << endl;
}*/
int main()
{
    Rectangle r1;
    r1.Display();
    r1.fun1();
    Rectangle r2(12, 13);
    r2.Display();
    Rectangle r3(r2);
    r3.Display();        
}
