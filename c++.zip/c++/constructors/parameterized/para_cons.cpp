#include <iostream>
using namespace std;
class Person {
	private:
		char ch;
		string name;
		int  age;
	public:
		Person(char ch, string name, int age) { 
			this->ch = ch;
			this->name = name;
			this->age = age;
		}
		void dispay() {
			cout << "The person data is : " << ch << " " << name << " " << age << endl;
		}
};
int main()
{
	char ch;
	string name;
	int age;
	cout << "Enter the ch :" << "\n";
	cin >> ch;
	cout << "Enter the string :" << "\n";
	cin >> name;
	cout << "Enter the age :" << "\n";
	cin >> age;
	Person p(ch, name, age);
	//cout << "Enter details of person " <<endl;
	p.dispay();
	return 0;
}
