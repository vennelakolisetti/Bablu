#include <iostream>
using namespace std;
class sample {

	private:
		int age;
		char ch;
		string name;
	public:
		sample(int age, char ch, string name) {
			this->age = age;
			this->ch = ch;
			this->name = name;
		}
		sample(int age, string name, char ch) {
			this->age = age;
			this->name = name;
			this->ch = 'F';
		}
		sample(char ch, int age, string name) {
			this->ch = ch;
			this->age = age;
			this->name = "Bablu";
		}
	 void display() {
			cout << "age is : " << age << endl;
			cout <<"char is: " << ch << endl;
			cout <<"name is: " << name << endl;
		}
};
int main()
{
	int age;
	char ch;
	string name;
	cout << "Enter p1 details :" << endl;
	cout << "Enter age : " << endl;
	cin >> age;
	cout << "Enter char :" << endl;
	cin >> ch ;
	cout << "Enter name : " << endl;
	cin >> name;
	sample p1(age, ch, name);
	p1.display();
	cout << "Enter p2 details : " << endl;
	cout << "Enter age : " << endl;
	cin >> age ;
	cout << "Enter name : " << endl;
	cin >> name ;
	sample p2(age, name, ch);
	p2.display();
	cout << "Enter p3 details : " << endl;
	cout << "Enter char: " << endl;
	cin >> ch;
	cout << "Enter age : " << endl;
   	cin	>> age;
	sample p3(ch, age, name);
	p3.display();
	return 0;
}
