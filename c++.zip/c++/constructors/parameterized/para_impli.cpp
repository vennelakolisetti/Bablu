#include <iostream>
using namespace std;
class sample {
	private:
		int num;
		string str;
	public:
		sample(int num, string str) {
			this -> num = num;
			this -> str = str;
		}
		void display() {
			cout << "Sample is : " << num <<" " << str << endl;
		}
};
int main()
{
	//sample s;
	int num;
	string str;
	cout <<"Enter number: " << endl;
	cin >> num;
	cout << "Enter str : " << endl;
	cin >> str;
	sample s(num, str);
	s.display();
	return 0;
}


