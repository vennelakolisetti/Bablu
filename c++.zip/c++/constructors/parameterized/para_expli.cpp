#include <iostream>
#include <cstring>
using namespace std;
class sample {
	private:
		int num;
		char name[10];
		double sal;
	public:
		sample(int n, char s[], double d);
		void display();
};
sample::sample(int n, char s[], double d) {
	num = n;
	//name = s;
	strcpy(name, s);
	sal = d;
}
void sample::display() {
	cout << "Number is: " << num << endl;
	cout << "name is : " << name << endl;
	cout << "sal is : " << sal << endl;
}
int main() {
	int num;
	char name[10];
	double sal;
	cout << "Enter num : " ;
	cin >> num;
	cout << "Enter name : ";
	cin >> name;
	cout << "Enter sal : ";
	cin >> sal;
	sample s(num, name, sal);
	s.display();
	return 0;
}
