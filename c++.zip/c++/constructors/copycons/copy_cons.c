#include <iostream>
using namespace std;
class sample {
	private:
		int num;
		int num1;
		string str;
		string str1;
	public:
		sample(int num, string str) {
			this->num = num;
			this->str = str;
		}
		sample(const sample& obj) {
			int num1 = obj.num;
			string str1 = obj.str;
		}
		void display() {
			cout << "NUM is : " << num << endl;
			cout << "NUM1 is : " << num1 << endl;
			cout << "str is : " << str << endl;
			cout << "str1 is : " << str1 << endl;
		}
};
int main()
{
	//sample s;
	int num;
	string str;
	cout << "Enter num : " << endl;
	cin >> num; 
	cout << "Enter str : " << endl;
	cin >> str;
	sample s1(num, str);
	s1.display();
	cout << "Enter num : " << endl;
	cin >> num; 
	cout << "Enter str : " << endl;
	cin >> str;
	sample s2(num, str);
	s2.display();
	return 0;
}
