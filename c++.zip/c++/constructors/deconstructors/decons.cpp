#include <iostream>
using namespace std;
class sample {
	private:
		int num;
		string s;
	public:
		sample() {
			cout << "Default constructor " << endl;
		}
		sample(int num, string s) {
			this -> num = num;
			this -> s = s;
		}
		~sample() {
			cout << "Deconstructor is called " << endl;
		}
		void display() {
			cout << "num is : " << num << endl;
			cout << "name is " << s << endl;
		}
};
int main()
{
	sample s1;
	int num;
	string s;
	cout << "Enter num is : " << endl;
	cin >> num;
	cout << "Enter name is : " << endl;
	cin >> s;
	sample s2(num, s);
	s2.display();
	//delete s1;
	//delete s2(num, s);
	return 0;
}
