#include <iostream>
using namespace std;
class Sample {
	// declaring private class data members
	private:
		int age;
		string name;
		float sal;
		 // declaring constructor
	public:
		Sample() {
			cout << "Default constructor is called : " << endl;
			cout << "Enter name of sample :" << endl;
			cin >> name;
			cout << "Enter age of smaple: " << endl;
			cin >> age;
			cout << "Enter sal : " << endl;
			cin >> sal;
		}
		void display() {
			cout << "Sampled data is : " << age << " " << name << " " << sal << endl;

		}
};
int main()
{
	Sample s;
	s.display();
	return 0;
}
