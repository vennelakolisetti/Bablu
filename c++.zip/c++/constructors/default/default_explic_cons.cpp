#include <iostream>
using namespace std;
class sample {
	private:
		int age;
		string name;
		float sal;
	public:
		sample();
		void display();
};
sample::sample() {
	cout << "Enter age of sample : " << endl;
	cin >> age;
	cout << "Enter name of the sample : " << endl;
	cin >> name;
	cout << "Enter the sal of compiler : " << endl;
	cin >> sal;
}
void sample::display() {
	cout << "Details are: " << age <<" " << name <<" " << sal << endl;
}
int main() {
	sample s;
	s.display();
	return 0;
}
