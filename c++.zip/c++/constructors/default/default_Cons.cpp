#if DQUES
#include <iostream>
using namespace std;
class Sample {
	public:
		//int x = 10;
		int x;
};
int main()
{
	Sample s;
	cout << "Value of x is : " << s.x << endl;
	return 0;
}
#endif
#include <iostream>
using namespace std;
class Sample {
	public:
	//private:
		int x;
	Sample() {
			 x = 10;
		}
};
int main()
{
	Sample s;
	cout << "X value is : " << s.x << endl;
	return 0;
}
