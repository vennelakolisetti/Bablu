#include <iostream>
#define SIZE 5
using namespace std;
int main()
{
	int num[SIZE];
	int i;
	int j;
	int max = num[0];
	int min = num[0];
	int temp[SIZE];
	cout << "Enter Elements into an array " << endl;
	for (i = 0; i < SIZE ; i++) {
		cin >> num[i];
	}
	for (i = 0; i < SIZE; i++) {
		if ( max < num[i] ) {
			max = num[i];
		}
		//if(i == 0){
		//	min = num[0];
		//}
		if ( min > num[i]) {
			min = num[i];
		}
	}
	cout << "MAX is : " <<  max << endl;
	cout << "Min is : " <<  min << endl;
	
}

