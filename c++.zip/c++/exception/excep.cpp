#include <iostream>
using namespace std;
int main() {
	int res;	
	cout << "Enter age " << endl;
	cin >> res;
	try {
		if (res < 17) {
			throw(res);
		} else {
			return res;
		}
	}
	catch(int res) {
		cout << "U can not drink " << endl;
		
	}
	cout << res;
}
