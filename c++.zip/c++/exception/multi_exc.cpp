#include <iostream>
//#include<conio.h>
using namespace std;

int main()
{
    int arr[3] = { -1, 2, 5 };
    for (int i = 0; i < 3; i++)
    {
        int num = arr[i];
        try
        {
            if (num == -1)
                // throwing numeric value as exception
                throw 1;
            else if (num == 2)
                // throwing a character/string as exception
                throw 'a';
            else
               throw "Generic";
        }
        catch (int ex) // to catch numeric exceptions
        {
            cout << "Integer Exception" << endl;
        }
        catch (char ex) // to catch character/string exceptions
        {
            cout << "Character Exception" << endl;
        }
        //Generic catch block
        catch (...) // to catch anytime of exceptions
        {
            cout << "Generic Exception" << endl;
        }
    }
    return 0;
}
