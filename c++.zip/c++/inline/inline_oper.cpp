#include <iostream>
using namespace std;
class opt {
	int add, sub, mul;
	float div;
	int a, b;
	public:
		void get();
		void summ();
		void subb();
		void mull();
		void divis();
};
inline void opt::get() {
	cout << "Enter a value :" << endl;
	cin >> a;
	cout << "Enter b value : " << endl;
	cin >> b;
}
inline void opt::summ() {
	static int add = a + b;
	cout << "Addition is : " << add << endl;
}
inline void opt::subb() {
	int diff = a - b ;
	cout << "Substraction is : " << diff << endl;
}
inline void opt::mull() {
	int multi = a * b;
	cout << "Multiplication is : " << multi << endl;
}
inline void opt::divis() {
	float division = a / b;
	cout << "Division is : " << division << endl;
}
int main()
{
	cout << "Using inline program " << endl;
	opt obj;
	obj.get();
	obj.summ();
	obj.subb();
	obj.mull();
	obj.divis();
	return 0;
}
		
