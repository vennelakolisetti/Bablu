#include <iostream>
using namespace std;
inline int get(int num);
int main()
{
	cout << "Value is : " << get(2) << endl;
	return 0;
}
inline int get(int num) {
	return num*num*num;
}
