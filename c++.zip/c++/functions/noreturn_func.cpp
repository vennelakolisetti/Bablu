#include <iostream>
#include <cstring>
using namespace std;
void fun(string name);
void func(int num);
int main()
{
	fun("Bablu");
	func(445);
	return 0;
}
void fun(string name) {
	cout << name << " " << "megha" << endl;
}
void func(int num) {
	cout << num << endl;
}
