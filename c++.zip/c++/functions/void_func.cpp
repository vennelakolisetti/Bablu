#include <iostream>
using namespace std;
void fun1();
void fun2();
int main() {
	fun1();
	fun2();
	cout << "Iam main function\n" << endl;
	return 0;
}
void fun1()
{
	cout << "I am function1 " << endl;
}
void fun2()
{
	cout << "I am function2 " << endl;
}

