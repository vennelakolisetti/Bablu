#include <iostream>
using namespace std;
void fun1(string name = "Bablu");
int main()
{
	fun1("Naidu");
	fun1();
	fun1("kolisetti");
	return 0;
}
void fun1(string name)
{
	cout << name << endl;
}
