#include <iostream>
using namespace std;
void fun(string name, int num);
int main()
{
	int age;
	string str;
	cout << "Enter name:"<< endl;
	cin >> str;
	cout << "Enter age : "<< endl;
	cin >> age;
	fun(str, age);
	//fun("Bablu", 21);
	//fun("Naidu", 445);
	return 0;
}
void fun(string name, int num) {
	cout << "Name is: " << name << endl << "Age is :" << num << endl;
}

