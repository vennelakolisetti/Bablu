#include <iostream>
using namespace std;
int fun1(int& , int& );
string fun2(string&, string&);
int main() {
	int x, y;
	string name1, name2;
	cout << "Enter x and y  value : " << endl;
	cin >> x >> y;
	cout << "Enter string1 " << endl;
	cin >> name1;
	cout << "Enter string2 " << endl;
	cin >> name2;
	cout << "Before fun1 " << endl;
	cout << x << " " << y << "\n";
	fun1(x, y);
	cout << x <<" " << y <<"\n";
	cout << "Before fun2 " << endl;
	cout << name1 << " " << name2; 
	fun2(name1, name2);
	cout << endl;
	cout << name1 << " " << name2;
	return 0;
}
int fun1(int &x, int &y) {
	int z = x;
	x = y;
	y = z;
	return x, y;
	//cout << x << " " << y << endl;
}
string fun2(string &name1, string &name2) {
	string temp = name1;
	name1 = name2;
	name2 = temp;
	return name1, name2;
}
