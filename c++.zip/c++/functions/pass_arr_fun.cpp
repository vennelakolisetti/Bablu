#include <iostream>
#define SIZE 100
using namespace std;
void myarr(int arr[], int);
int main() {
	int arr[SIZE];
	int i;
	int num;
	cout << "Enter number : " <<endl;
	cin >> num;
	for (i = 0; i < num; i++) {
		cin >> arr[i];
	}
	myarr(arr, num);
	return 0;
}
void myarr(int arr[SIZE], int num) {
	int i;
	for (i = num ; i > 0 ; i--) {
		cout << arr[i] << endl;
	}
}	
