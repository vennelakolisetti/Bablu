#include <iostream>
#include <cstring>
using namespace std;
int fun1(int, int);
string fun1(string, string);
char fun1(char);
float fun1(float, float);
int main() {
	int a, b;
	string s1, s2;
	char ch;
	float f1, f2;
	cout << "Enter a value " << endl;
	cin >> a;
	cout << "Enter b value " << endl;
	cin >> b;
	cout << "Enter string1 " << endl;
	cin >> s1;
	cout << "Enter string2 " << endl;
	cin >> s2;
	cout << "Enter character " << endl;
	cin >> ch;
	cout << "Enter float1 val : " << endl;
	cin >> f1;
	cout << "Enter float val : " << endl;
	cin >> f2;
	cout << fun1(a, b) << endl;
	cout << fun1(s1, s2) << endl; 
	cout << fun1(ch) << endl;;
	cout << fun1(f1, f2);
	return 0;
}
int fun1(int n1, int n2) {
	int num = n1 + n2;
	return num;
	//cout << num << endl;
}
string fun1(string str1, string str2) {
	string s = str1 + str2;
	return s;
	//cout << s << endl;
}
char fun1(char ch1) {
	char ch = ch1;
	return ch1;
	//cout << ch1 << endl;
}
float fun1(float n1, float n2) {
	float num = n1 + n2;
	return num;
	//cout << num << endl;
}

