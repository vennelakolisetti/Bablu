#include <iostream>
using namespace std;
int fun1(int num);
string fun2(string str);
int main()
{
	int n;
	string str;
	cout << "Enter a number : " << endl;
	cin >> n;
	cout << "Enter a string : " << endl;
	cin >> str;
	//fun1(n);
	cout << fun1(n) << "\n"; 
	cout << fun2(str);
	//fun2(str);

	return 0;
}
int fun1(int n) {
	return 10 + n;
}
string fun2(string name) {
	return " naidu " + name;
}
