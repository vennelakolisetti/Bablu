#include <iostream>
using namespace std;
int sum(int num);
int main() {
	int n; 
	cout << "Enter a number:" << endl;
	cin >> n;
	cout << sum(n);
	return 0;
}
int sum(int n) {
	if (n > 0) {
		return n + sum(n - 1);
	} else {
		return 0;
	}
}

