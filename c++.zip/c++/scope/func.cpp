/*Beginning of Distlib.cpp*/
/*Implementation file for the class Distance*/
#include "Class.h"
void Class::setFeet(int x) //definition
{
	iFeet = x;
}
int Class::getFeet() //definition
{
	return iFeet;
}
void Class::setInches(float y) //definition
{
	fInches = y;
}
float Class::getInches() //definition
{
	return fInches;
}
/*End of Distlib.cpp*/ 
