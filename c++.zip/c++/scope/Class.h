/*Beginning of Distance.h*/
/*Header file containing the definition of the Distance class*/
class Class {
	int iFeet;
	float fInches;
public:
	void setFeet(int); //prototype only
	int getFeet(); //prototype only
	void setInches(float); //prototype only
	float getInches(); //prototype only
};
/*End of Distance.h*/ 
