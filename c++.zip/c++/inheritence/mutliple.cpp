#include <iostream>
using namespace std;
class p1 { //Base1
public:
	int age;
	string str1;
	p1() {
		age = 21;
		str1 = "Bablu";
	}
	void fun1() {
		cout << "I am p1 " << age << " " << str1 << endl;
	}
};
class p2 { //Base2
public:
	int age1;
	string str2;
	p2() {
		age1 = 22;
		str2 = "Vennela";
	}
	void fun2() {
		cout << "I am p2 " << age1  << " " << str2 << endl;
	}
};
class p3 { //Base3
public:	
	int age2;
	string str3;
	p3() {
		age2 = 23;
		str3 = "Ammaa";
	}
	void fun3() {
		cout << "I am p3 " << age2 << " " << str3 << endl;
	}
};
class C: public p1, public p2, public p3 {
public:
	int age3;
	string str4;
	C() {
		age3 = 24;
		str4 = "Nanna";
	}
	void fun4() {
		cout << "I am child " << age3  << " " << str4 << endl;
		cout << "Multiple " << age + age1 + age2 +age3 << " " << str1 + str2 + str3 + str4 << endl;
	}
};
int main()
{
	C c;
	c.fun1();
	c.fun2();
	c.fun3();
	c.fun4();
	return 0;
}
