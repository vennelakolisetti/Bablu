#include <iostream>
using namespace std;
class Father {
	public:
		string str;
		Father() {
			str = "I am father ";
		}
		void fun1() {
			cout << str << endl;
		}
};
class Mother {
	public:
		string str1;
		Mother() {
			str1 = "I am Mother ";
		}
		void fun2() {
			cout << str1 << endl;
		}
};
class Child : public Father, public Mother {
	public:
		string str2;
		Child() {
			str2 = "Bablu";
		}
		void fun3() {
			cout << "I am child of " << str2  << " " << str + str1 << endl;

		}
};
class Friend : public Child {
	public:
		string str3;
		Friend() {
			str3 = " I am friend of child ";
		}
		void fun4() {
			cout << "I am friend of " << str2 << endl;
		}
};
int main() {
	Child c;
	c.fun3();
	Friend f;
	f.fun4();
	return 0;
}
