#include <iostream>
using namespace std;
class Father {
	public:
		int land;
		string name;
		Father() {
			land  = 10;
			name = "Kolisetti";
		}
		void fun1() {
			cout << land << " " <<  endl;
		}
};
class child1 : public Father {
	public:
		string car;
		int cash ;
		child1() {
			car = "BMW";
			cash = 12000;
		}
		void fun2() {
			cout << land << " " << cash << " " << name + car << endl;
		}
};
class child2 : public Father {
	public:
		string house;
		int age;
		child2() {
			house = "Duplex";
			age = 21;
		}
		void fun3() {
			cout << land << " " << age << " " << name + house << endl;
		}
};
int main() 
{
	Father f;
	f.fun1();
	child1 c1;
	c1.fun2();
	child2 c2;
	c2.fun3();
	return 0;
}

