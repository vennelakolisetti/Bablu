#include <iostream>
using namespace std;
class Parent {
	public:
		int x;
		void fun1() {
			cout << x << endl;
		}
};
class Child: public Parent {
	public:
		int y;
		void fun2() {
			cout << x <<" " << y << endl;
		}
};
int main()
{
	Parent p;
	cout << "Enter a val " << endl;
	cin >> p.x;
	p.fun1();
	Child c;
	cout << "Enter a value and b vale " << endl;
	cin >> c.x;
	cin >> c.y;
	c.fun2();
	return 0;
}


