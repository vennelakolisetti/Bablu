#include <iostream>
using namespace std;
class GP {
	public:
		int a;
		string s;
		GP() {	
			a = 10;
			s = "GP";
		}
		void fun1() {
			cout << "I'm GP " << a << " " << s << endl;
		}
};
class PP : public GP {
	public:
		int b;
		string str;
		PP() {
			b = 5;
			str = "PP";
		}
		void fun2() {
			cout << "I am PP " << (a + b) << " " << s + str << endl;
		}
};
class GPC : public PP {
	public:
		int c;
		string strg;
		GPC() {
			c = 5;
			strg = "GPC";
		}
		void fun3() {
			cout << "I am GPC " << (a + b + c) << " " << s + str + strg << endl;
		}
};
int main()
{
	GPC gpc;
	gpc.fun1();
	gpc.fun2();
	gpc.fun3();
	return 0;
}

