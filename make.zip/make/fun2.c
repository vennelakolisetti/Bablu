#include "hdr.h"
void func2() {
	printf("Hello Im func2\n");
}
