#include "hdr.h"
int main()
{
	printf("Im Main func\n");
	func1();
	func2();
	func3();
	func4();
	func5();
	return 0;
}
