#include "hdr.h"
void func1() {
	printf("Hello Im func1\n");
}
