#include "hdr.h"
void func5() {
	printf("Hello Im func5\n");
}
