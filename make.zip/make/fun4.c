#include "hdr.h"
void func4() {
	printf("Hello Im func4\n");
}
