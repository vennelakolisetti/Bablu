#include "hdr.h"
void func3() {
	printf("Hello Im func3\n");
}
